#!/usr/bin/env python3
"""toobix – lokale, offline Solidaritäts-Werkzeuge.

Alles läuft lokal auf deinem Rechner: keine Cloud, kein Tracking.

Nutzung:
    python3 toobix.py bedarf         -> zeigt deine Bedürfnisse aus bedarf.txt
    python3 toobix.py credits        -> zeigt das Credits-Logbuch
    python3 toobix.py netzwerk       -> listet dein lokales Solidar-Netzwerk
    python3 toobix.py add-angebot <Was> <Dauer> -> Trägt ein Angebot in die credits.csv ein
    python3 toobix.py match          -> Vergleicht deine Angebote mit dem Netzwerk-Bedarf
"""

import csv
import os
import sys
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def get_path(filename):
    return os.path.join(BASE_DIR, filename)

def show_bedarf() -> None:
    path = get_path("bedarf.txt")
    if not os.path.exists(path):
        print("bedarf.txt fehlt.")
        return
    with open(path, encoding="utf-8") as f:
        print(f.read())

def show_credits() -> None:
    path = get_path("credits.csv")
    if not os.path.exists(path):
        print("credits.csv fehlt.")
        return
    with open(path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        print("Keine Einträge.")
        return
    total = sum(int(r.get("wert_credits", 0) or 0) for r in rows)
    print(f"{'Datum':<12} {'Wer':<10} {'Art':<20} {'Credits':<8} Bemerkung")
    print("-" * 75)
    for r in rows:
        print(f"{r.get('datum', ''):<12} {r.get('wer', ''):<10} {r.get('art', ''):<20} "
              f"{r.get('wert_credits', ''):<8} {r.get('bemerkung', '')}")
    print("-" * 75)
    print(f"Gesamt-Credits (Dein Saldo): {total}")

def show_netzwerk() -> None:
    path = get_path("netzwerk.csv")
    if not os.path.exists(path):
        print("netzwerk.csv fehlt noch. Bitte mit 'python3 toobix.py' arbeiten, wenn sie existiert.")
        return
    with open(path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    print(f"{'Organisation':<25} {'Bietet':<25} {'Sucht':<25}")
    print("-" * 75)
    for r in rows:
        print(f"{r.get('organisation', ''):<25} {r.get('bietet', ''):<25} {r.get('sucht', ''):<25}")
    print("-" * 75)

def add_angebot(was: str, dauer_stunden: str) -> None:
    path = get_path("credits.csv")
    file_exists = os.path.exists(path)
    
    datum = datetime.now().strftime("%Y-%m-%d")
    credits = int(dauer_stunden) * 5  # 1 Stunde = 5 Credits
    
    with open(path, mode="a", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["datum", "wer", "rolle", "angebot_oder_bedarf", "art", "wert_credits", "bemerkung"])
        writer.writerow([datum, "Michael", "bieter", was, "zeit_kompetenz", credits, "Eingetragen über add-angebot"])
    print(f"Angebot eingetragen: '{was}' für {dauer_stunden}h (+{credits} Credits).")

def run_match() -> None:
    print("Match-Making Analyse...")
    print("Suche nach Überschneidungen zwischen deinem Angebot (Organisation/IT)")
    print("und dem Bedarf deines Netzwerks (netzwerk.csv).")
    print("-" * 50)
    
    netz_path = get_path("netzwerk.csv")
    if not os.path.exists(netz_path):
        print("Fehler: netzwerk.csv existiert nicht. Bitte erst Netzwerk aufbauen.")
        return
        
    match_gefunden = False
    with open(netz_path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
        for r in rows:
            sucht = r.get("sucht", "").lower()
            if "organisation" in sucht or "it" in sucht or "büro" in sucht or "struktur" in sucht:
                print(f"✅ MATCH GEFUNDEN bei: {r.get('organisation')}")
                print(f"   Sie suchen: {r.get('sucht')}")
                print(f"   Sie bieten: {r.get('bietet')}")
                print(f"   Aktion: Erstelle ein Pitch-Dokument für {r.get('organisation')}!")
                match_gefunden = True
                
    if not match_gefunden:
        print("Aktuell keine direkten automatischen Matches gefunden.")

def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
        
    cmd = sys.argv[1]
    if cmd == "bedarf":
        show_bedarf()
    elif cmd == "credits":
        show_credits()
    elif cmd == "netzwerk":
        show_netzwerk()
    elif cmd == "add-angebot":
        if len(sys.argv) < 4:
            print("Nutzung: python3 toobix.py add-angebot <Was> <Dauer_in_Stunden>")
        else:
            add_angebot(sys.argv[2], sys.argv[3])
    elif cmd == "match":
        run_match()
    elif cmd in ("help", "-h", "--help"):
        print(__doc__)
    else:
        print(f"Unbekanntes Kommando: {cmd}")
        print(__doc__)
        sys.exit(1)

if __name__ == "__main__":
    main()
