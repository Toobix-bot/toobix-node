# Solidaritäts-Starterkit: Lokale Ressourcen & Zeit-Tauschringe organisieren

Dieses Leitfaden-Paket richtet sich an lokale Vereine, Initiativen, Begegnungsstätten, Tafeln und engagierte Einzelpersonen. Es bietet eine einfache, geldlose Methode, um vorhandene Ressourcen (Überfluss) mit drängenden Bedürfnissen (Mangel) auf lokaler Ebene zu verbinden.

---

## 1. Das Grundprinzip: Mangel, Gleichgewicht, Überfluss

In jeder Stadt und in jedem Dorf existieren zeitgleich:
*   **Überfluss:** Ungenutzte Räume außerhalb der Öffnungszeiten, überschüssige Lebensmittel, reparierbare Sachspenden, Fachwissen oder freie Zeitstunden.
*   **Mangel:** Erschöpfung, Obdachlosigkeit, Einsamkeit, Bürokratie-Überlastung, Mangel an Nahrung oder Kleidung.

**Das Ziel dieses Starterkits:** 
Diese beiden Zustände ohne den Zwang von Finanzkapital transparent zusammenzuführen.

---

## 2. Die drei Werkzeuge im Paket

### Werkzeug A: Das CLI-Tool (`toobix.py`)
Ein einfaches, offline-fähiges Python-Skript für die lokale Verwaltung von Zeit-Credits und Netzwerk-Kontakten.
*   `python3 toobix.py netzwerk`: Zeigt lokale Partner und deren Angebote/Bedarfe.
*   `python3 toobix.py match`: Gleicht Fähigkeiten (z.B. IT-Hilfe) mit Bedarfen ab.
*   `python3 toobix.py add-angebot`: Bucht geleistete Unterstützung als Solidar-Credits ab.

### Werkzeug B: Die Toobix Node 2.0 Webanwendung
Eine datenschutzkonforme (0% Tracking, 0% Cookies) Benutzeroberfläche für den Browser.
*   **Balance-Tacho:** Ermöglicht Hilfesuchenden und Helfenden, ihren eigenen Kapazitätsstatus ehrlich einzuschätzen.
*   **Tauschbörse:** Übersichtliches Gegenüberstellen von Angeboten und Gesuchen.
*   **SOS-Netzwerk:** Schneller Zugriff auf anonyme Krisenhotlines und psychosoziale Dienste.

### Werkzeug C: Die Vorlage für Tauschangebote (`pitch_inklusiva.md`)
Eine beispielhafte Vereinbarung für den 1-zu-1-Tausch:
*"Ich biete X Stunden IT-/Büro-Strukturierung pro Woche und erhalte im Gegenzug Y (z.B. Schreibtischplatz, Verpflegung)."*

---

## 3. Schritt-für-Schritt Anleitung zur Einführung in einer Initiative

1.  **Erhebung der Kapazitäten:** Erfasst in eurer Gruppe, wo ihr Überfluss habt (z.B. warme Räume, Suppenküche) und wo ihr Unterstützung benötigt (z.B. Datenpflege, Reparaturen).
2.  **Transparente Bewertung:** Nutzt *Solidar-Credits (SC)* als faire Referenzgröße (z.B. 1 Stunde Hilfe = 10 SC, 1 Mahlzeit = 5 SC).
3.  **Lokaler Aushang / Web-Knotenpunkt:** Öffnet die `index.html` der Webanwendung oder druckt den `flyer_solidaritaet.html` aus, um die Möglichkeiten im Nachbarschaftstreff sichtbar zu machen.

---

## 4. Datenschutz & Unabhängigkeit

*   Das gesamte Paket läuft **100% lokal** auf jedem handelsüblichen Computer.
*   Es werden **keine Daten ins Internet übertragen**.
*   Es entstehen **keine laufenden Lizenz- oder Serverkosten**.
